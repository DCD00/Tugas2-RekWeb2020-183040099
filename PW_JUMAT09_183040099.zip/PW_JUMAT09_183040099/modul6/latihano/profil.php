<?php 
// cek apakah tidak ada data di $_GET
if(	!isset($_GET["no"])) {
	// redirect
	header("Location: index.php");
	exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Profil</title>
	<link rel="stylesheet" type="text/css" href="css5/profil.css">
</head>
<body>
	<div>
		<h1><em>Spesifikasi Smartphone</em></h1>

		<table cellspacing="0" cellpadding="3" align="center">
			<tr align="center">
				<td align="center"><img src="img/<?= $_GET["gambar"]; ?>"></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["basic%info"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["netcon"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["descreen"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["softhard"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["memory"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["camera"] ?></td>
			</tr>
			<tr align="center">
				<td>Features <?= $_GET["otherfeatures"] ?></td>
			</tr>
			<tr align="center">
				<td>Battery <?= $_GET["battery"] ?> </td>
			</tr>
			<tr align="center">
				<td>Harga <?= $_GET["harga"] ?></td>
			</tr>
		</table>

		<br>

		<a href="index.php">Kembali</a>
	</div>
</body>
</html>