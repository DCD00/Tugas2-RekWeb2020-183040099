<?php
$smartphone = [
	[
		"no" => "1",
		"gambar" => "x7.png",
		"basic info" => "Xiaomi Redmi 7",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.2, Hotspot, GPS, USB micro",
		"descreen" => "Material aluminum, Ukuran 159x76x8 mm, Berat 180 gram <br>Layar 6.26 inch, Resolusi 1520x720 Pixel, Technology screen IPS</br> ", 
		"softhard" => "OS Android 9.0 Pie, Chipset Qualcomm Snapdragon 632",
		"memory" => "RAM 3 GB, Internal 32 GB, Eksternal up to 512GB",
		"camera" => "Kamera belakang 12 MP dan 2 MP, Depan 8 MP",
		"battery" => "Non-Removable 4000 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Proximity, Compass",
		"harga" => "Rp 1.949.000"
	],
	[
		"no" => "2",
		"gambar" => "M1.png",
		"basic info" => "Asus Zenfone Max Pro M1",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.2, Hotspot, GPS, USB micro",
		"descreen" => "Material aluminum, Ukuran 159x76x8 mm, Berat 180 gram <br>Layar 5.99 inch, Resolusi 2160x1080 Pxl, Technology screen IPS</br> ", 
		"softhard" => "OS Android 8.1 Oreo, Chipset Qualcomm Snapdragon 636",
		"memory" => "RAM 3 GB, Internal 32 GB, Eksternal up to 128GB",
		"camera" => "Kamera belakang 13 MP dan 5 MP, Depan 8 MP",
		"battery" => "Non-Removable 5000 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Proximity, Compass",
		"harga" => "Rp 1.599.000"
	],
	[
		"no" => "3",
		"gambar" => "f5.png",
		"basic info" => "Oppo F5",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.2, Hotspot, GPS, USB micro</br>",
		"descreen" => "Material aluminum, Ukuran 156x76x7 mm, Berat 152 gram <br>Layar 6 inch, Resolusi 2160x1080 Pxl, Technology screen TFT</br>", 
		"softhard" => "OS Android 7.1 Nouget, Chipset Mediatek Helio P23",
		"memory" => "RAM 4 GB, Internal 32 GB, Eksternal up to 256GB",
		"camera" => "Kamera Belakang 16 MP, Depan 20 MP</br>",
		"battery" => "Non-Removable 3200 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Proximity, Compass",
		"harga" => "Rp 1.899.000"
	],
	[
		"no" => "4",
		"gambar" => "y7.png",
		"basic info" => "Huawei Y7 Pro",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.2, Hotspot, GPS, USB micro",
		"descreen" => "Material aluminum, Ukuran 159x77x8 mm, Berat 168 gram <br>Layar 6.26 inch, Resolusi 1520x720 Pixel, Technology screen IPS</br>", 
		"softhard" => "OS Android Version 8.1 Oreo, Chipset Qualcomm Snapdragon 450",
		"memory" => "RAM 3 GB, Internal 32 GB, Eksternal up to 512GB",
		"camera" => "Kamera Belakang 13 MP dan 2 MP, Depan 8 MP</br>",
		"battery" => "Non-Removable 4000 mAh",
		"otherfeatures" => "Accelerometer, Proximity, Compass",
		"harga" => "Rp 1.845.000"
	],
	[
		"no" => "5",
		"gambar" => "y95.png",
		"basic info" => "Vivo Y95",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.2, Hotspot, GPS, USB micro",
		"descreen" => "Material aluminum, Ukuran 155x75x8 mm, Berat 163.5 gram <br>Layar 6.22 inch, Resolusi 1520 x 720 Pixel, Technology screen IPS</br>", 
		"softhard" => "OS Android Version 8.1 Oreo, Chipset Qualcomm Snapdragon 439",
		"memory" => "RAM 4 GB, Internal 64 GB, Eksternal up to 256GB",
		"camera" => "Kamera Belakang 13 MP dan 2 MP, Depan 20 MP</br>",
		"battery" => "Non-Removable 4000 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Gyroscope, Proximity, Compass",
		"harga" => "Rp 2.215.000"
	],
	[
		"no" => "6",
		"gambar" => "m20.png",
		"basic info" => "Samsung Galaxy M20",
		"netcon" => "Jaringan 3G, 4G Wi-Fi Bluetooth 5.0, GPS, GLONASS, USB micro",
		"descreen" => "Material aluminum, ukuran 156.5x74.5x9 mm, Berat 186 gram <br>Layar 6.3 inch, Resolusi 2340x1080 Pixel, Technology TFT</br>",
		"softhard" => "OS Android Version 8.1 Oreo, Chipset Exynos 7904",
		"memory" => "RAM 3 GB, Internal 32 GB, Eksternal up to 512GB",
		"camera" => "Kamera Belakang 13 MP dan 5 MP, Depan 8 MP</br>",
		"battery" => "Non-Removable 5000 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Gyroscope, Proximity, Compass",
		"harga" => "Rp 2.499.000"
	],
	[
		"no" => "7",
		"gambar" => "n5.png",
		"basic info" => "Nokia 5",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.2, NFC, Hotspot, GPS, USB micro",
		"descreen" => "Material aluminum, Ukuran 149.7x72.5x8 mm, Berat 160 gram <br>Layar 5.2 inch, Resolusi 1280x720 Pixel, Technology screen IPS</br>", 
		"softhard" => "OS Android Version 7.1 Nouget, Chipset Qualcomm Snapdragon 430",
		"memory" => "RAM 3 GB, Internal 16 GB, Eksternal up to 256GB",
		"camera" => "Kamera Belakang 13 MP, Depan 8 MP",
		"battery" => "Non-Removable 3000 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Gyroscope, Proximity, Compass",
		"harga" => "Rp 1.465.000"
	],
	[
		"no" => "8",
		"gambar" => "s3.png",
		"basic info" => "Infinix Hot S3X",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 5.0, Hotspot, GPS, USB micro",
		"descreen" => "Material Polikarbonat, Ukuran 156x75x8 mm, Berat 175 gram <br>Layar 6.2 inch, Resolusi 1440x720 Pixel, Technology screen IPS</br>", 
		"softhard" => "OS Android Version 8.1 Oreo, Chipset Qualcomm Snapdragon 430",
		"memory" => "RAM 3 GB, Internal 32 GB, Eksternal up to 128GB",
		"camera" => "Kamera Belakang 13 MP dan 2 MP, Depan 16 MP</br>",
		"battery" => "Non-Removable 4000 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Gyroscope, Proximity, Compass",
		"harga" => "Rp 1.550.000"
	],
	[
		"no" => "9",
		"gambar" => "i6.png",
		"basic info" => "Iphone 6S",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.1, NFC, Hotspot, GPS, USB 2.0",
		"descreen" => "Material Metal, Ukuran 138x67x7 mm, Berat 143 gram <br>Ukuran Layar 4.7 inch, Resolusi 1334x750 Pixel, Technology screen IPS</br>", 
		"softhard" => "OS IOS 9, up to 10 Chipset Apple A9",
		"memory" => "RAM 2 GB, Internal 64 GB</br>",
		"camera" => "Belakang 12 MP Flash, Depan 5 MP</br>",
		"battery" => "Non-Removable 1715 mAh",
		"otherfeatures" => "Fingerprint, Accelerometer, Gyroscope, Proximity, Compass, Siri",
		"harga" => "Rp 2.850.000"
	],
	[
		"no" => "10",
		"gambar" => "c1.png",
		"basic info" => "Realme C1",
		"netcon" => "Jaringan 3G, 4G, Wi-Fi, Bluetooth 4.1, Hotspot, GPS, USB Micro",
		"descreen" => "Material Plastik, Ukuran 156x75.6x8 mm, Berat 168 gram <br>Layar 6.2 inch, Resolusi 1520X720 Pixel, Technology screen IPS</br>", 
		"softhard" => "OS Android Version 8.1 Oreo, Chipset Qualcomm Snapdragon 450",
		"memory" => "RAM 2 GB, Internal 16 GB, Eksternal Up to 256GB",
		"camera" => "Belakang 15 MP dan 2 MP, Depan 5 MP",
		"battery" => "Non-Removable 4230 mAh",
		"otherfeatures" => "Accelerometer, Proximity, Compass",
		"harga" => "Rp 1.399.000"
	],
];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="css5/index.css">
</head>
<body>

	<h2>Daftar Smartphone Murah Terbaru April 2019</h2>

	<div class="box">
		<ul>
			<?php foreach ($smartphone as $smart): ?>
			<div  class="a">
				<img width="80" src="img/<?= $smart["gambar"]; ?>">
	
				<p class="b"><a href="profil.php?no=<?= $smart['no']; ?>&gambar=<?= $smart['gambar']; ?>&basic%info=<?= $smart['basic info']; ?>&netcon=<?= $smart['netcon']; ?>&descreen=<?= $smart['descreen']; ?>&softhard=<?= $smart['softhard']; ?>&memory=<?= $smart['memory']; ?>&camera=<?= $smart['camera']; ?>&battery=<?= $smart['battery']; ?>&otherfeatures=<?= $smart['otherfeatures']; ?>&harga=<?= $smart['harga']; ?>">
				<?= $smart['basic info']; ?>
				</a></p>

				<p class="c"><?= $smart['harga'] ?></p>
			</div>
			<?php endforeach; ?>
		</ul>
	</div>

</body>
</html>