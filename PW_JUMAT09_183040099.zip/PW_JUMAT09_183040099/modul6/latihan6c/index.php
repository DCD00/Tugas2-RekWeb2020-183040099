<?php 
require 'php/function.php';
$smartphone = query("SELECT * FROM smartphone");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6c</title>
	<style>
		.container {
			width: 380px;
			height: 1510px;
			background-color: orange;
			margin: 30px auto;
			padding: 10px;
			box-shadow: 0 0 10px 10px rgba(0,0,0,.75);
			transition: .3s;
			position: relative;
		}

		.content img {
			border-radius: 50%;
			float: left;
		}

		h2 {
			text-align: center;

		}

		.content a {
			color: blue;
			font-weight: bold;
			text-decoration: none;
		}

		.content a:hover{
			color: white;
		}

		.container:hover {
			box-shadow: inset 0 0 10px 10px rgba(0,0,0,.85);
		}

		.content {
			width: 320px;
			height: 100px;
			background-color: white;
			margin: 10px auto;
			padding: 20px;
			position: relative;
			left: -30px;
			top: -6px;
			text-align: center;
		}

		.nama a{
			font-size : 20px;
		}

		.nama a:hover {
			color: red;
		}

		.c {
			color: black;
			font-weight: bold;
		}
	</style>
</head>
<body>

	<center><em><h1>Daftar Smartphone Murah Terbaru April 2019</h2></em></center>

	<div class="container">
		<ul>
			<?php foreach ($smartphone as $smart ) : ?>
			<div class="content">
				<img width="80" src="img/<?= $smart["gambar"]; ?>">
				<p class="nama">
					<a href="php/profil.php?id=<?= $smart['id'] ?>"><?= $smart['nama']; ?></a>
				</p>
				<p class="c"><?= $smart['harga'] ?></p>
			</div>
			<?php endforeach; ?>
		</ul>
	</div>
</body>
</html>