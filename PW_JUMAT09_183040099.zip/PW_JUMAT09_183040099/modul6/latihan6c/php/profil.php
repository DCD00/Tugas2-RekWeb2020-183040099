<?php 
// cek apakah tidak ada data di $_GET
if(	!isset($_GET["id"])) {
	// redirect
	header("Location: ../index.php");
	exit;
}

require 'function.php';
$id = $_GET['id'];

$smart = query("SELECT * FROM smartphone WHERE id = $id")[0];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profil</title>
	<style>
		.container h1{
			text-align: center;
		}
		.content {
			border: 10px solid grey;
			width: 435px;
			height: 470px;
			color: black;
			background-color: orange;
			margin: 20px auto;
			text-align: center;
		}
		.content img{
			padding: 20px;
			border-radius: 20%;
		}
		
		.a a{
			color: black;
			text-decoration: none;
			font-weight: bold;
		}

		.a a:hover {
			color: white;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<div class="container">
		<h1>Spesifikasi Smartphone</h1>

		<div class="content">
			<div class="gambar">
				<img src="../img/<?= $smart['gambar'] ?>">
			</div>
			<div class="desc">
				<table cellspacing="0" cellpadding="3">
					<tr>
						<td class="nama"><?= $smart["nama"]; ?></td>
					</tr>
					<tr>
						<td><?= $smart["netcon"]; ?></td>
					</tr>
					<tr>
						<td width="300"><?= $smart["descreen"]; ?></td>
					</tr>
					<tr>
						<td><?= $smart["softhard"]; ?></td>
					</tr>
					<tr>
						<td><?= $smart["camera"] ?></td>
					</tr>
					<tr>
						<td><?= $smart["memory"] ?></td>
					</tr>
					<tr>
						<td><?= $smart["battery"] ?></td>
					</tr>
					<tr>
						<td><?= $smart["features"] ?></td>
					</tr>
					<tr>
						<td><?= $smart["harga"]; ?></td>
					</tr>
				</table>
			</div>

			<p class="a"><a href="../index.php">Kembali</a></p>
			
		</div>
	</div>
</body>
</html>