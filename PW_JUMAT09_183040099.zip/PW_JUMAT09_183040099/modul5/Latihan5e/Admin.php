<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
	<style type="text/css">
		div{
			border: 1px solid white;
			width: 500px;
			height: 150px;
			color: white;
			background-color: brown;
			margin: 20px auto;
			text-align: center;
		}

		div a{
			color: black;
		}
	</style>
</head>
<body>

	<div>
		<h1><em>Selamat datang Admin</em></h1>

		<button><a href="login.php">Logout</a></button>
	</div>
	
</body>
</html>